const { Provider, Wallet } = require("zksync-web3");
const { ethers } = require("ethers");

// zkSync Provider
const zkSyncProvider = new Provider("https://mainnet.era.zksync.io"); // Mainnet

// Wallet setup
const privateKey = "0x21fa1bf8dc9793971382c89776e623f9177e4e30b24537d1b2f9383dc46a00c6";
const wallet = new Wallet(privateKey, zkSyncProvider);

async function main() {
    // Check wallet balance
    const balance = await wallet.getBalance("ETH"); // Replace "ETH" with ERC-20 address if needed
    console.log(`Wallet Balance: ${ethers.utils.formatEther(balance)} ETH`);

    // Example: Sending tokens
    const recipient = "0xRecipientAddress"; // Replace with recipient address
    const amount = ethers.utils.parseEther("0.01"); // Replace with desired amount
    const tx = await wallet.sendTransaction({
        to: recipient,
        value: amount
    });
    console.log("Transaction Hash:", tx.hash);
    await tx.wait();
    console.log("Transaction Confirmed!");
}

main().catch((error) => {
    console.error("Error:", error);
});
