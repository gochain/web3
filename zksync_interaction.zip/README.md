# zkSync Interaction for Okeamah

## Overview
This project demonstrates basic Layer 2 interactions on zkSync using the Okeamah project. It includes wallet setup, balance checking, and token transfers.

## Requirements
- Node.js installed on your system.
- An Ethereum wallet private key (used securely).

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the script:
   ```bash
   npm start
   ```

## Notes
- Replace placeholder values (e.g., `0xRecipientAddress`) with actual values.
- Keep your private key secure and do not share it publicly.
