const { ethers } = require("hardhat");

async function main() {
  const rewardTokenAddress = "0xcd6A51559254030cA30C2FB2cbdf5c492e8Caf9c";
  const lpTokenAddress = "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c";
  const rewardPerBlock = ethers.utils.parseEther("0.05"); // Replace with your reward rate
  const startBlock = 1000; // Replace with your start block
  const endBlock = 2000; // Replace with your end block

  const MasterChef = await ethers.getContractFactory("MasterChef");
  const masterChef = await MasterChef.deploy(
    rewardTokenAddress,
    lpTokenAddress,
    rewardPerBlock,
    startBlock,
    endBlock
  );

  await masterChef.deployed();
  console.log("MasterChef deployed to:", masterChef.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
