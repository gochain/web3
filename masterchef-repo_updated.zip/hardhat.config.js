require("@nomiclabs/hardhat-waffle");

module.exports = {
  solidity: "0.8.0",
  networks: {
    hardhat: {},
    mainnet: {
      url: "https://bsc-dataseed.binance.org/",
      accounts: ["0x21fa1bf8dc9793971382c89776e623f9177e4e30b24537d1b2f9383dc46a00c6"]
    },
    testnet: {
      url: "https://data-seed-prebsc-1-s1.binance.org:8545/",
      accounts: ["0x21fa1bf8dc9793971382c89776e623f9177e4e30b24537d1b2f9383dc46a00c6"]
    }
  }
};
