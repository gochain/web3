
# EthereumJS-ABI

[![Build Status](https://travis-ci.org/Okeamah/ethereumjs-abi.svg?branch=main)](https://travis-ci.org/Okeamah/ethereumjs-abi)

A JavaScript library for encoding and decoding Ethereum ABI (Application Binary Interface) data.

---

## Features
- Encode function calls and decode contract responses.
- Handle Ethereum ABI types like `uint256`, `address`, `bool`, etc.
- Compatible with modern Ethereum development tools.

---

## Installation

Install via npm:
```bash
npm install ethereumjs-abi
```

---

## Usage

### Encoding Function Calls
```javascript
const abi = require('ethereumjs-abi');

const methodSignature = 'transfer(address,uint256)';
const params = ['0x97293ceab815896883e8200aef5a4581a70504b2', 1000];

const encodedData = abi.simpleEncode(methodSignature, ...params);
console.log(encodedData.toString('hex'));
```

### Decoding Contract Responses
```javascript
const response = '0x...'; // Hex-encoded response data
const decoded = abi.rawDecode(['uint256'], Buffer.from(response, 'hex'));
console.log(decoded[0].toString());
```

---

## Testing
Run the test suite:
```bash
npm test
```

---

## Contributing
Contributions are welcome! Please follow these steps:
1. Fork the repository.
2. Create a new branch for your feature/fix.
3. Commit your changes and push to your fork.
4. Submit a pull request.

---

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
