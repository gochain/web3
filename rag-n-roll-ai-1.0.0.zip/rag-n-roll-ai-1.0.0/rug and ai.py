import snowflake.connector
import streamlit as st
import pandas as pd

# Snowflake connection details
def connect_to_snowflake():
    try:
        conn = snowflake.connector.connect(
            user="OKEAMAH",                      # Your Snowflake username
            password="Agunnaya112",               # Your Snowflake password
            account="jivxtcf-vr80909",            # Your Snowflake account URL (without https://)
            warehouse="okeamah_warehouse",        # Your Snowflake warehouse name
            database="my_database",               # Your Snowflake database name
            schema="my_schema"                    # Your Snowflake schema name
        )
        return conn
    except Exception as e:
        st.error("Error connecting to Snowflake: " + str(e))
        return None

# Function to query data from Snowflake
def query_snowflake(query):
    conn = connect_to_snowflake()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute(query)
            result = cursor.fetchall()
            return pd.DataFrame(result, columns=["ID", "Text Column"])
        except Exception as e:
            st.error(f"Error executing query: {str(e)}")
            return pd.DataFrame()
        finally:
            cursor.close()
            conn.close()

# Function to display search results
def display_search_results(query):
    snowflake_query = f"SELECT * FROM my_schema.my_table WHERE text_column LIKE '%{query}%'"
    results = query_snowflake(snowflake_query)
    if not results.empty:
        st.write("Search Results:")
        st.write(results)
    else:
        st.write("No results found.")

# Streamlit app UI
st.title("AI Search with Snowflake")
user_query = st.text_input("Enter your search query:")

if user_query:
    display_search_results(user_query)
