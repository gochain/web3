# rag-n-roll-ai
an intelligent search platform that combines Snowflake, Cortex Search, and Mistral LLM to deliver enhanced data retrieval and AI-generated insights. Built with Streamlit, the platform allows users to query large datasets and receive contextually relevant results and summaries. The app provides an interactive and user-friendly interface
